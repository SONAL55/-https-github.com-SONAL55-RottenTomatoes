package app2.example.hp.com.myapplication;

/**
 * Created by SIDDHARTH on 1/10/2016.
 */
public class Keys {
    public class EndpointBoxOffice {
        public static final String KEY_MOVIES = "movies";
        public static final String KEY_ID = "id";
        public static final String KEY_TITLE = "title";
        public static final String KEY_RELEASE_DATE = "release_dates";
        public static final String KEY_THEATER = "theater";
        public static final String KEY_RATING = "ratings";
        public static final String KEY_AUDIENCE_SCORE = "audience_score";
        public static final String KEY_SYNOPSIS = "synopsis";
        public static final String KEY_POSTERS = "posters";
        public static final String KEY_THUMBNAIL = "thumbnail";
        public static final String KEY_LINKS = "links";
        public static final String KEY_SELF = "self";
        public static final String KEY_CAST = "cast";
        public static final String KEY_REVIEWS = "reviews";
        public static final String KEY_SIMILAR = "similar";
    }
}
