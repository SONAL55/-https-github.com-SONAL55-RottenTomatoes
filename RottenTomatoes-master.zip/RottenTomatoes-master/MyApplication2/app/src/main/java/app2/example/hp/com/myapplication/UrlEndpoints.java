package app2.example.hp.com.myapplication;

/**
 * Created by SIDDHARTH on 1/10/2016.
 */
public class UrlEndpoints {
    public static final String URL_BOX_OFFICE = "http://api.rottentomatoes.com/api/public/v1.0/lists/movies/box_office.json";
    public static final String URL_CHAR_QUESION = "?";
    public static final String URL_CHAR_AMEPERSTAND = "&";
    public static final String URL_PARAM_API_KEY = "apikey=";
    public static final String URL_PARAM_LIMIT = "limit=";

}
